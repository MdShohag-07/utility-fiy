
<?php $__env->startSection('title', 'Statement #'.$statement->id); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-content px-4 py-4 md:px-6 md:py-6">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-xl md:text-2xl font-semibold text-gray-700">
            Statement Details: #<?php echo e($statement->id); ?>

        </h1>
        <a href="<?php echo e(route('admin.statements.index')); ?>" class="btn btn-secondary text-sm">
            <i class="fas fa-arrow-left fa-fw mr-1"></i> Back to List
        </a>
    </div>
    <hr class="mb-5">

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div class="md:col-span-2 widget-card shadow-md border rounded-lg">
            <div class="widget-header bg-gray-50 p-4 border-b">
                <h3 class="text-lg font-medium">Statement for <?php echo e($statement->user->display_name ?? 'N/A'); ?></h3>
            </div>
            <div class="widget-content p-6 space-y-4">
                <p><strong>Statement Date:</strong> <?php echo e($statement->formatted_statement_date); ?></p>
                <p><strong>Due Date:</strong> <?php echo e($statement->formatted_due_date); ?></p>
                <p><strong>Status:</strong> <span class="badge badge-<?php echo e($statement->status === 'paid' ? 'success' : 'warning'); ?>"><?php echo e(ucfirst($statement->status)); ?></span></p>
                <p><strong>Total Amount:</strong> <span class="font-semibold text-xl">$<?php echo e(number_format($statement->total_amount, 2)); ?></span></p>

                <h4 class="text-md font-semibold pt-4 border-t mt-4">Line Items:</h4>
                <?php if($statement->items->isNotEmpty()): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="p-2 text-left">Description</th>
                                <th class="p-2 text-right">Qty</th>
                                <th class="p-2 text-right">Unit Price</th>
                                <th class="p-2 text-right">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $statement->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b">
                                <td class="p-2"><?php echo e($item->description); ?></td>
                                <td class="p-2 text-right"><?php echo e($item->quantity); ?></td>
                                <td class="p-2 text-right">$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td class="p-2 text-right font-medium">$<?php echo e(number_format($item->amount, 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="font-semibold bg-gray-50">
                                <td colspan="3" class="p-2 text-right">Total:</td>
                                <td class="p-2 text-right">$<?php echo e(number_format($statement->total_amount, 2)); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-gray-500">No line items for this statement.</p>
                <?php endif; ?>
            </div>
             <div class="widget-footer p-4 bg-gray-50 border-t text-right">
                <a href="<?php echo e(route('admin.statements.downloadPdf', $statement->id)); ?>" class="btn btn-primary">
                    <i class="fas fa-file-pdf mr-1"></i> Download PDF
                </a>
            </div>
        </div>

        
        <div class="md:col-span-1 widget-card shadow-md border rounded-lg">
            <div class="widget-header bg-gray-50 p-4 border-b">
                <h3 class="text-lg font-medium">User Information</h3>
            </div>
            <div class="widget-content p-6 space-y-2">
                <p><strong>Name:</strong> <?php echo e($statement->user->display_name ?? 'N/A'); ?></p>
                <p><strong>Email:</strong> <?php echo e($statement->user->email ?? 'N/A'); ?></p>
                <p><strong>Account #:</strong> <?php echo e($statement->user->account_number ?? 'N/A'); ?></p>
                <?php if($statement->user->address): ?>
                <p><strong>Address:</strong><br>
                    <?php echo e($statement->user->address); ?><br>
                    <?php echo e($statement->user->city); ?>, <?php echo e($statement->user->state); ?> <?php echo e($statement->user->zip_code); ?>

                </p>
                <?php endif; ?>
                <div class="pt-3">
                     <a href="<?php echo e(route('admin.users.edit', $statement->user->id)); ?>" class="text-blue-600 hover:underline text-sm">
                        View/Edit User Profile <i class="fas fa-external-link-alt fa-xs"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/admin/statements/show.blade.php ENDPATH**/ ?>