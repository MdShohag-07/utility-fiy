

<aside class="dashboard-sidebar public-sidebar hidden md:block">
    <nav>
        <ul>
            
            <?php $__empty_1 = true; $__currentLoopData = $headerMenuItems ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $itemUrlPath = ltrim(parse_url($item->url, PHP_URL_PATH) ?? '/', '/');
                    $currentPath = request()->path() === '/' ? '' : ltrim(request()->path(), '/');
                    $isActive = false;
                    if ($itemUrlPath === '' && $currentPath === '') { $isActive = true; }
                    elseif ($itemUrlPath !== '' && str_starts_with($currentPath, $itemUrlPath)) { $isActive = true; }
                    if(isset($active) && $active === Str::slug(strtolower($item->title))) { $isActive = true; }
                ?>
                <li>
                    <a href="<?php echo e($item->url); ?>" target="<?php echo e($item->target ?? '_self'); ?>" class="<?php echo e($isActive ? 'active' : ''); ?>">
                        <i class="<?php echo e($item->icon ?? 'fas fa-angle-right'); ?> fa-fw sidebar-icon"></i>
                        <span class="sidebar-text"><?php echo e($item->title); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>
                    <a>
                        <i class="fas fa-exclamation-circle fa-fw sidebar-icon"></i>
                        <span class="sidebar-text">No Menu Items Configured</span>
                    </a>
                </li>
            <?php endif; ?>
            


            
            
            
            
            
             

             
             
            <?php if(auth()->guard()->check()): ?>
                 <li class="mt-auto pt-4 border-t border-gray-700">
                     <a href="#logout"
                        onclick="event.preventDefault(); if(confirm('Are you sure you want to log out?')) { document.getElementById('public_sidebar_logout_form').submit(); }"> 
                         <i class="fa-solid fa-arrow-right-from-bracket fa-fw sidebar-icon"></i>
                         <span class="sidebar-text">Logout</span>
                     </a>
                     <form id="public_sidebar_logout_form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
                 </li>
            <?php endif; ?>
        </ul>
    </nav>
</aside><?php /**PATH C:\Users\shoha\Downloads\utility\resources\views/partials/public_home_sidebar.blade.php ENDPATH**/ ?>