
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    
    
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin.css', 'resources/js/app.js']); ?>

    
    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body class="admin-body"> 

    
    <div class="admin-layout-wrapper"> 

        
        
        <?php echo $__env->make('partials.admin_sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="admin-main-content"> 

            
            <header class="admin-top-bar"> 
                 <div class="page-title"><?php echo $__env->yieldContent('title', 'Dashboard'); ?></div>
                 <div class="admin-user-menu">
                     
                     <span>Admin: <?php echo e(Auth::user()?->first_name ?? Auth::user()?->name ?? 'User'); ?></span>
                     <a href="#" onclick="event.preventDefault(); document.getElementById('admin-logout-form-top').submit();" class="admin-logout-link">Logout</a>
                     <form id="admin-logout-form-top" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
                 </div>
            </header>

            
            <main class="admin-page-content"> 
                
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div> 

    </div> 

    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/layouts/admin.blade.php ENDPATH**/ ?>