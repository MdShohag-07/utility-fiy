


<?php if(session('status')): ?>
    <div class="alert alert-success mb-4 p-3 rounded-md text-sm" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>


<?php if(session('error')): ?>
    <div class="alert alert-danger mb-4 p-3 rounded-md text-sm" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div class="alert alert-danger mb-4 p-3 rounded-md text-sm" role="alert">
        <strong class="font-semibold block mb-1">Please fix the following errors:</strong>
        <ul class="list-disc list-inside ml-1">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/partials/admin_alerts.blade.php ENDPATH**/ ?>