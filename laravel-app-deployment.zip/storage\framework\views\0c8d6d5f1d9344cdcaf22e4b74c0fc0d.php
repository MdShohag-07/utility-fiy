
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['active' => false, 'icon' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['active' => false, 'icon' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?> 

<?php
// Base class for structure, styling handled by CSS targeting '.dropdown-link-item'
$classes = 'dropdown-link-item';
if ($active ?? false) {
    $classes .= ' active'; // Add 'active' class if needed (styling for active state defined in CSS)
}
?>


<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    
    <?php if($icon): ?>
        <i class="<?php echo e($icon); ?>" aria-hidden="true"></i>
    <?php endif; ?>
    
    <span><?php echo e($slot); ?></span>
</a><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/components/dropdown-link.blade.php ENDPATH**/ ?>