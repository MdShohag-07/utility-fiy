


<?php $__env->startSection('title', 'Create New Statement'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-content px-4 py-4 md:px-6 md:py-6">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-xl md:text-2xl font-semibold text-gray-700">
            <i class="fas fa-file-invoice-dollar fa-fw mr-2 text-blue-500"></i> Create New Statement
        </h1>
        <a href="<?php echo e(route('admin.statements.index')); ?>" class="btn btn-secondary text-sm">
            <i class="fas fa-arrow-left fa-fw mr-1"></i> Back to Statements List
        </a>
    </div>
    <hr class="mb-5">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4 p-3 rounded-md text-sm">
            <strong class="font-semibold">Creation Failed!</strong> Check the errors below.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?> <div class="alert alert-success mb-4 p-3 rounded-md text-sm"><?php echo e(session('status')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?> <div class="alert alert-danger mb-4 p-3 rounded-md text-sm"><?php echo e(session('error')); ?></div> <?php endif; ?>

    <div class="widget-card shadow-md border border-gray-100 rounded-lg overflow-hidden">
        <div class="widget-header bg-gray-50 border-b border-gray-200 p-3 md:p-4">
            <h3 class="text-base font-medium text-gray-700">Statement Details</h3>
        </div>
        <form action="<?php echo e(route('admin.statements.store')); ?>" method="POST" class="widget-content bg-white p-4 md:p-6 space-y-4">
            <?php echo csrf_field(); ?>

            
            <div>
                <label for="user_ids" class="block text-sm font-medium text-gray-700 mb-1">Select User(s) <span class="text-red-500">*</span></label>
                <select name="user_ids[]" id="user_ids" class="form-select w-full rounded-md border-gray-300 shadow-sm" multiple required>
                    
                    
                    <?php $__empty_1 = true; $__currentLoopData = $usersForSelect ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $displayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((is_array(old('user_ids')) && in_array($id, old('user_ids'))) ? 'selected' : ''); ?>>
                            <?php echo e($displayName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="" disabled>No users available.</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['user_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['user_ids.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="statement_date" class="block text-sm font-medium text-gray-700 mb-1">Statement Date <span class="text-red-500">*</span></label>
                    <input type="date" name="statement_date" id="statement_date" value="<?php echo e(old('statement_date', now()->format('Y-m-d'))); ?>" class="form-input" required>
                    <?php $__errorArgs = ['statement_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="due_date" class="block text-sm font-medium text-gray-700 mb-1">Due Date <span class="text-red-500">*</span></label>
                    <input type="date" name="due_date" id="due_date" value="<?php echo e(old('due_date', now()->addDays(14)->format('Y-m-d'))); ?>" class="form-input" required>
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="border-t border-gray-200 pt-4 mt-4">
                <div class="flex justify-between items-center mb-2">
                    <h4 class="text-md font-medium text-gray-700">Line Items <span class="text-red-500">*</span></h4>
                    <button type="button" id="add-item-btn" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-plus fa-fw mr-1"></i> Add Item
                    </button>
                </div>
                <div id="line-items-container" class="space-y-3">
                    
                    <?php if(old('items')): ?>
                        <?php $__currentLoopData = old('items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="line-item grid grid-cols-12 gap-2 items-center p-2 border rounded-md">
                                <div class="col-span-5">
                                    <input type="text" name="items[<?php echo e($index); ?>][description]" placeholder="Description" value="<?php echo e($item['description'] ?? ''); ?>" class="form-input text-sm" required>
                                </div>
                                <div class="col-span-2">
                                    <input type="number" name="items[<?php echo e($index); ?>][quantity]" placeholder="Qty" value="<?php echo e($item['quantity'] ?? ''); ?>" class="form-input text-sm item-quantity" min="1" required>
                                </div>
                                <div class="col-span-3">
                                    <input type="number" name="items[<?php echo e($index); ?>][unit_price]" placeholder="Unit Price" value="<?php echo e($item['unit_price'] ?? ''); ?>" class="form-input text-sm item-unit-price" step="0.01" min="0" required>
                                </div>
                                <div class="col-span-1 text-sm item-amount text-right pr-1">
                                    
                                    $<?php echo e(number_format(($item['quantity'] ?? 0) * ($item['unit_price'] ?? 0), 2)); ?>

                                </div>
                                <div class="col-span-1">
                                    <button type="button" class="btn btn-sm btn-danger remove-item-btn"><i class="fas fa-trash"></i></button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        
                        <div class="line-item grid grid-cols-12 gap-2 items-center p-2 border rounded-md">
                            <div class="col-span-5">
                                <input type="text" name="items[0][description]" placeholder="Description" class="form-input text-sm" required>
                            </div>
                            <div class="col-span-2">
                                <input type="number" name="items[0][quantity]" placeholder="Qty" value="1" class="form-input text-sm item-quantity" min="1" required>
                            </div>
                            <div class="col-span-3">
                                <input type="number" name="items[0][unit_price]" placeholder="Unit Price" class="form-input text-sm item-unit-price" step="0.01" min="0" required>
                            </div>
                            <div class="col-span-1 text-sm item-amount text-right pr-1">
                                $0.00 
                            </div>
                            <div class="col-span-1">
                                
                                <button type="button" class="btn btn-sm btn-danger remove-item-btn" style="display:none;"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['items.*.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>


            <div class="pt-3 text-right">
                <button type="submit" class="btn btn-primary shadow-md hover:shadow-lg">
                    <i class="fas fa-save fa-fw mr-1"></i> Create Statement(s)
                </button>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<style>
    .form-input, .form-select { border: 1px solid #d1d5db; padding: 0.5rem 0.75rem; border-radius: 0.375rem; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05); width: 100%;}
    .form-input:focus, .form-select:focus { outline: none; border-color: var(--primary-color, #6366f1); box-shadow: 0 0 0 2px var(--primary-color-light, #a5b4fc); }
    .alert { border: 1px solid transparent; }
    .alert-danger { background-color: #fee2e2; border-color: #fecaca; color: #991b1b; }
    .alert-success { background-color: #d1fae5; border-color: #a7f3d0; color: #065f46; }
    /* Select2 specific styles if needed */
    .select2-container .select2-selection--multiple { min-height: 38px !important; border: 1px solid #d1d5db !important; }
    .select2-container--default .select2-selection--multiple .select2-selection__choice { background-color: #e0e7ff; border-color: #c7d2fe; color: #3730a3; }
    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove { color: #4338ca; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('#user_ids').select2({
        placeholder: "-- Please select user(s) --",
        allowClear: true
    });

    let itemIndex = <?php echo e(old('items') ? count(old('items')) : 1); ?>; // Start index for new items

    // Function to update item amount and total
    function updateAmounts(itemRow) {
        const quantity = parseFloat($(itemRow).find('.item-quantity').val()) || 0;
        const unitPrice = parseFloat($(itemRow).find('.item-unit-price').val()) || 0;
        const amount = quantity * unitPrice;
        $(itemRow).find('.item-amount').text('$' + amount.toFixed(2));
        // You could also calculate a grand total here if needed
    }

    // Add new item row
    $('#add-item-btn').on('click', function() {
        const newItemHtml = `
        <div class="line-item grid grid-cols-12 gap-2 items-center p-2 border rounded-md">
            <div class="col-span-5">
                <input type="text" name="items[${itemIndex}][description]" placeholder="Description" class="form-input text-sm" required>
            </div>
            <div class="col-span-2">
                <input type="number" name="items[${itemIndex}][quantity]" placeholder="Qty" value="1" class="form-input text-sm item-quantity" min="1" required>
            </div>
            <div class="col-span-3">
                <input type="number" name="items[${itemIndex}][unit_price]" placeholder="Unit Price" class="form-input text-sm item-unit-price" step="0.01" min="0" required>
            </div>
             <div class="col-span-1 text-sm item-amount text-right pr-1">
                $0.00
            </div>
            <div class="col-span-1">
                <button type="button" class="btn btn-sm btn-danger remove-item-btn"><i class="fas fa-trash"></i></button>
            </div>
        </div>`;
        $('#line-items-container').append(newItemHtml);
        itemIndex++;
        toggleRemoveButtons();
    });

    // Remove item row
    $('#line-items-container').on('click', '.remove-item-btn', function() {
        if ($('#line-items-container .line-item').length > 1) {
            $(this).closest('.line-item').remove();
        }
        toggleRemoveButtons();
    });

    // Calculate amount on quantity or unit price change
    $('#line-items-container').on('input', '.item-quantity, .item-unit-price', function() {
        updateAmounts($(this).closest('.line-item'));
    });

    // Initial calculation for pre-filled items (e.g., on validation error)
    $('#line-items-container .line-item').each(function() {
        updateAmounts(this);
    });

    function toggleRemoveButtons() {
        const items = $('#line-items-container .line-item');
        if (items.length <= 1) {
            items.find('.remove-item-btn').hide();
        } else {
            items.find('.remove-item-btn').show();
        }
    }
    toggleRemoveButtons(); // Initial check
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/admin/statements/create.blade.php ENDPATH**/ ?>