
<aside class="admin-sidebar">
    <div class="sidebar-header">
        
        
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center justify-center py-4"> 
            <img src="<?php echo e($siteLogoUrl ?? asset('images/admin-logo-placeholder.png')); ?>"
                 alt="<?php echo e(config('app.name', 'Utility Site')); ?> Admin Logo"
                 class="admin-logo h-10 w-auto"> 
        </a>
        
    </div>
    <nav class="sidebar-nav">
        <ul>
            
            <li class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fa-solid fa-gauge-high fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">Dashboard</span>
                </a>
            </li>

            
            <li class="<?php echo e(request()->routeIs('admin.users.*') && !request()->routeIs('admin.users.link.*') ? 'active' : ''); ?>"> 
                <a href="<?php echo e(route('admin.users.index')); ?>">
                    <i class="fa-solid fa-users-cog fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">User Manager</span>
                </a>
            </li>

            
            <li class="sidebar-heading"><span>Content Management</span></li>

            
             <li class="<?php echo e(request()->routeIs('admin.pages.homepage.*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.pages.homepage.edit')); ?>">
                      <i class="fas fa-home fa-fw sidebar-icon"></i>
                      <span class="sidebar-text">Homepage</span>
                  </a>
             </li>

             
            <li class="<?php echo e(request()->routeIs('admin.statements.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.statements.index')); ?>">
                    <i class="fa-solid fa-file-lines fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">Statements</span>
                </a>
            </li>

            
            
            <li class="<?php echo e(request()->routeIs('admin.settings.pdf.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.settings.pdf.edit')); ?>">
                    <i class="fas fa-file-invoice fa-fw sidebar-icon"></i> 
                    <span class="sidebar-text">PDF Content</span>
                </a>
            </li>
            

             
             <li class="<?php echo e(request()->routeIs('admin.billing.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.billing.index')); ?>">
                    <i class="fa-solid fa-file-invoice-dollar fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">Billing Manager</span>
                </a>
            </li>

            
             <li class="<?php echo e(request()->routeIs('admin.menus.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.menus.index')); ?>">
                    <i class="fa-solid fa-bars fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">Menu Manager</span>
                </a>
            </li>

            
              <li class="<?php echo e(request()->routeIs('admin.footer.*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.footer.edit')); ?>">
                      <i class="fa-solid fa-shoe-prints fa-fw sidebar-icon"></i>
                      <span class="sidebar-text">Footer Info</span>
                  </a>
              </li>

            
             <li class="sidebar-heading"><span>Configuration</span></li>

            
             <li class="<?php echo e(request()->routeIs('admin.settings.general.*') ? 'active' : ''); ?>">
                 <a href="<?php echo e(route('admin.settings.general.edit')); ?>">
                    <i class="fas fa-cog fa-fw sidebar-icon"></i>
                    <span class="sidebar-text">General Settings</span>
                </a>
             </li>

             
             <li class="<?php echo e(request()->routeIs('admin.users.link.*') ? 'active' : ''); ?>">
                  <a href="<?php echo e(route('admin.users.link.show')); ?>">
                      <i class="fas fa-link fa-fw sidebar-icon"></i>
                      <span class="sidebar-text">Link Users</span>
                  </a>
             </li>

             
             <li class="mt-auto pt-4 border-t border-gray-700">
                 <a href="#logout"
                    onclick="event.preventDefault(); if(confirm('Are you sure you want to log out?')) { document.getElementById('admin-logout-form-sidebar').submit(); }">
                     <i class="fa-solid fa-arrow-right-from-bracket fa-fw sidebar-icon"></i>
                     <span class="sidebar-text">Logout</span>
                 </a>
                 <form id="admin-logout-form-sidebar" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                     <?php echo csrf_field(); ?>
                 </form>
             </li>
        </ul>
    </nav>
</aside><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/partials/admin_sidebar.blade.php ENDPATH**/ ?>