



<div>
    <label for="first_name" class="block text-sm font-medium text-gray-700 mb-1">First Name <span class="text-red-500">*</span></label>
    <input type="text" name="first_name" id="first_name" class="form-input w-full" value="<?php echo e(old('first_name', $user->first_name ?? '')); ?>" required>
    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
    <label for="last_name" class="block text-sm font-medium text-gray-700 mb-1">Last Name <span class="text-red-500">*</span></label>
    <input type="text" name="last_name" id="last_name" class="form-input w-full" value="<?php echo e(old('last_name', $user->last_name ?? '')); ?>" required>
    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
    <label for="username" class="block text-sm font-medium text-gray-700 mb-1">Username <span class="text-red-500">*</span></label>
    <input type="text" name="username" id="username" class="form-input w-full" value="<?php echo e(old('username', $user->username ?? '')); ?>" required>
     <p class="text-xs text-gray-500 mt-1">Must be unique.</p>
    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address <span class="text-red-500">*</span></label>
    <input type="email" name="email" id="email" class="form-input w-full" value="<?php echo e(old('email', $user->email ?? '')); ?>" required>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
     
    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password <?php if(isset($user)): ?><span class="text-gray-500 text-xs">(Leave blank to keep current)</span><?php else: ?><span class="text-red-500">*</span><?php endif; ?></label>
    <input type="password" name="password" id="password" class="form-input w-full" <?php echo e(isset($user) ? '' : 'required'); ?> autocomplete="new-password">
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
    <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1">Confirm Password <?php if(isset($user)): ?><span class="text-gray-500 text-xs">(Required if changing password)</span><?php else: ?><span class="text-red-500">*</span><?php endif; ?></label>
    <input type="password" name="password_confirmation" id="password_confirmation" class="form-input w-full" <?php echo e(isset($user) ? '' : 'required'); ?> autocomplete="new-password">
    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div>
    <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Role <span class="text-red-500">*</span></label>
    <select name="role" id="role" class="form-select w-full" required>
        <option value="<?php echo e(\App\Models\User::ROLE_USER); ?>" <?php echo e(old('role', $user->role ?? \App\Models\User::ROLE_USER) == \App\Models\User::ROLE_USER ? 'selected' : ''); ?>>User</option>
        <option value="<?php echo e(\App\Models\User::ROLE_ADMIN); ?>" <?php echo e(old('role', $user->role ?? '') == \App\Models\User::ROLE_ADMIN ? 'selected' : ''); ?>>Admin</option>
    </select>
     <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/admin/users/_form-fields.blade.php ENDPATH**/ ?>