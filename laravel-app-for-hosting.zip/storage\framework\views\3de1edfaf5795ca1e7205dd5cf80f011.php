
<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-content px-4 py-4 md:px-6 md:py-6">
    
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-xl md:text-2xl font-semibold text-gray-700">Edit User: <?php echo e($user->full_name); ?></h1>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary text-sm"><i class="fas fa-arrow-left fa-fw mr-1"></i> Back</a>
    </div>
    <hr class="mb-5">
    <?php if($errors->any()): ?> <div class="alert alert-danger mb-4"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div> <?php endif; ?>

    <div class="widget-card shadow rounded-lg overflow-hidden">
         <div class="widget-header bg-gray-50 border-b p-4"><h3 class="font-medium">User Details</h3></div>
         <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST" class="widget-content bg-white p-6 space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> 

            
            <?php echo $__env->make('admin.users._form-fields', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="pt-3 text-right">
                <button type="submit" class="btn btn-primary"><i class="fas fa-sync-alt mr-1"></i> Update User</button>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>