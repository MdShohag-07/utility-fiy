




<?php $__env->startSection('title', 'Sign In'); ?> 

<?php $__env->startSection('content'); ?>
    
    <div class="login-page-container container mx-auto flex justify-center items-center py-12 md:py-20 min-h-[calc(100vh-250px)]"> 

         
         
         
         <div class="login-card w-full max-w-lg bg-white p-8 md:p-10 rounded-lg shadow-md border border-gray-200">

            <h1 class="login-title text-3xl font-bold text-gray-800 mb-4 text-center">
                Sign In to Get Started
            </h1>

            
            <div class="separator flex items-center my-6">
                <hr class="flex-grow border-gray-300">
                <span class="mx-4 text-gray-500 text-sm font-medium">or</span>
                <hr class="flex-grow border-gray-300">
            </div>

            
            <div class="text-center mb-6">
                
                <a href="<?php echo e(route('signup')); ?>" class="text-blue-600 hover:underline font-medium">
                    Create a Username
                </a>
            </div>

            
            <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

            
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Username/Email -->
                
                <div class="form-group mb-4">
                    <label for="login" class="form-label flex justify-between items-center">
                        <span>Username</span>
                        <button type="button" class="help-icon text-gray-500 hover:text-blue-600 text-xs" aria-label="Username help"> <i class="fas fa-question-circle"></i> </button>
                    </label>
                    <input id="login" class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="login" value="<?php echo e(old('login')); ?>" required autofocus autocomplete="username" />
                    
                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password -->
                <div class="form-group mb-4">
                    <label for="password" class="form-label"> Password </label>
                    <div class="password-wrapper relative">
                        <input id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> pr-10" type="password" name="password" required autocomplete="current-password" />
                        <button type="button" class="toggle-password absolute top-0 right-0 h-full px-3 text-gray-500 hover:text-blue-600" aria-label="Show password"> <i class="fas fa-eye"></i> </button>
                    </div>
                     <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Remember Me -->
                <div class="form-group mb-6 flex items-center justify-between">
                     <label for="remember_me" class="inline-flex items-center text-sm">
                        <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-blue-500 mr-2" name="remember">
                        <span class="text-gray-700">Stay Signed In on This Device</span>
                    </label>
                    <button type="button" class="help-icon text-gray-500 hover:text-blue-600 text-xs" aria-label="Stay signed in help"> <i class="fas fa-question-circle"></i> </button>
                </div>

                <!-- Sign In Button -->
                <div class="form-group mb-6">
                    <button type="submit" class="btn btn-primary w-full justify-center py-3"> Sign In </button>
                </div>

                <!-- Forgot Links -->
                <div class="text-center">
                    
                    <a class="text-sm text-blue-600 hover:underline rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                       href="<?php echo e(route('forgot.username')); ?>?or=<?php echo e(route('password.request')); ?>"> 
                        Forgot Username or Password?
                    </a>
                </div>
            </form>
        </div> 
    </div> 
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
<style>
    /* Minimal overrides if needed, but prefer app.css */
    /* Example: body { background-color: #f0f4f8; } */
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Password toggle JS (keep if not already in app.js)
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/auth/login.blade.php ENDPATH**/ ?>