 
<?php $__env->startSection('title', 'Billing Statements'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-semibold mb-6">Billing Statements</h1>

    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <section class="mb-10">
        <h2 class="text-2xl font-medium mb-4">Current Statement</h2>
        <?php if($currentStatement): ?>
            <div class="bg-white shadow-md rounded-lg p-6">
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p class="text-lg font-semibold">
                            Statement for <?php echo e($currentStatement->formatted_statement_date); ?>

                        </p>
                        <p class="text-sm text-gray-600">
                            Due Date: <?php echo e($currentStatement->formatted_due_date); ?>

                        </p>
                        <p class="text-lg font-semibold mt-1">
                            Amount Due: $<?php echo e(number_format($currentStatement->total_amount, 2)); ?>

                        </p>
                    </div>
                    <div class="mt-4 sm:mt-0">
                        
                        <a href="<?php echo e(route('my-account.billing.statement.downloadPdf', $currentStatement->id)); ?>"
                           class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-150 ease-in-out">
                            Download PDF
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-gray-100 border border-gray-300 text-gray-700 px-4 py-3 rounded">
                No current statement available.
            </div>
        <?php endif; ?>
    </section>

    
    <section>
        <h2 class="text-2xl font-medium mb-4">Past Statements</h2>
        <?php if($pastStatements->isNotEmpty()): ?>
            <div class="bg-white shadow-md rounded-lg overflow-hidden">
                <table class="min-w-full leading-normal">
                    <thead>
                        <tr>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Statement Date
                            </th>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Due Date
                            </th>
                             <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Amount
                            </th>
                            <th class="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pastStatements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <?php echo e($statement->formatted_statement_date); ?>

                                </td>
                                <td class="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <?php echo e($statement->formatted_due_date); ?>

                                </td>
                                <td class="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    $<?php echo e(number_format($statement->total_amount, 2)); ?>

                                </td>
                                <td class="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <a href="<?php echo e(route('my-account.billing.statement.downloadPdf', $statement->id)); ?>"
                                       class="text-indigo-600 hover:text-indigo-900 font-medium">
                                        Download
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-6">
                <?php echo e($pastStatements->links()); ?>

            </div>
        <?php else: ?>
            <div class="bg-gray-100 border border-gray-300 text-gray-700 px-4 py-3 rounded">
                No past statements found.
            </div>
        <?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user_dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/user/billing/statements.blade.php ENDPATH**/ ?>