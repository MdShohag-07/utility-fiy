


<div class="bill-details-page-content">
    
    <table class="no-border" style="margin-bottom: 15px;">
        <tr>
            <td style="width: 70%; vertical-align: bottom;">
                <h1 class="bill-details-title">Your Bill Details</h1>
            </td>
            <td style="width: 30%; text-align: right; font-size: 7pt; vertical-align: bottom;">
                Service from <?php echo e($statement->service_period_start ? \Carbon\Carbon::parse($statement->service_period_start)->format('M j') : 'N/A'); ?> - <?php echo e($statement->service_period_end ? \Carbon\Carbon::parse($statement->service_period_end)->format('M j, Y') : 'N/A'); ?>

            </td>
        </tr>
    </table>

    
    <div class="bill-details-box">
        <table class="activity-table">
            <thead>
                
                <tr class="balance-header-row">
                    <th style="width: 80%; text-align: left; padding: 6px 8px;">Previous Balance</th>
                    <th style="width: 20%; text-align: right; padding: 6px 8px;">$<?php echo e(number_format($statement->previous_balance ?? 0.00, 2)); ?></th>
                </tr>
                <tr class="balance-header-row">
                    <th style="padding: 6px 8px;">Remaining Balance</th>
                    <th style="text-align: right; padding: 6px 8px;">$<?php echo e(number_format(($statement->previous_balance ?? 0.00) - ($statement->payments_received ?? 0.00), 2)); ?></th>
                </tr>
                
                <tr class="activity-main-header-row">
                    <th colspan="2" style="padding: 8px; text-align:left; font-size:10pt;">Current Activity</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Conceptual grouping of items.
                    // For a real-world scenario, your StatementItem model should have a 'category'
                    // or you should pass pre-grouped items from the controller.
                    $groupedItems = $statement->items->groupBy(function($item) {
                        if (stripos($item->description, 'Community Solutions') !== false || stripos($item->description, 'TV Select') !== false || stripos($item->description, 'Disney+') !== false || stripos($item->description, 'ViX Premium') !== false || stripos($item->description, 'Paramount+') !== false || stripos($item->description, 'Max with Ads') !== false) return 'Community Solutions Services';
                        if (stripos($item->description, 'TV') !== false || stripos($item->description, 'Entertainment View') !== false || stripos($item->description, 'Sports View') !== false || stripos($item->description, 'Multi-dvr') !== false ) return 'Spectrum TV®';
                        if (stripos($item->description, 'Internet') !== false || stripos($item->description, 'WiFi') !== false || stripos($item->description, 'Gig') !== false) return 'Spectrum Internet®';
                        return 'Other Services'; // Default category
                    });

                    $categoryOrder = ['Community Solutions Services', 'Spectrum TV®', 'Spectrum Internet®', 'Other Services'];
                    $categoryTotals = [];
                ?>

                <?php $__currentLoopData = $categoryOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($groupedItems[$categoryName]) && $groupedItems[$categoryName]->isNotEmpty()): ?>
                        <?php
                            $itemsInCategory = $groupedItems[$categoryName];
                            $categoryTotals[$categoryName] = $itemsInCategory->sum(function($item) {
                                // Only sum if not 'Included' (assuming 'notes' field or similar)
                                return (isset($item->notes) && strtolower(trim($item->notes)) === 'included') ? 0 : $item->amount;
                            });
                        ?>
                        
                        <tr class="category-title-row">
                            <td colspan="2" class="bold"><?php echo e($categoryName); ?></td>
                        </tr>
                        
                        <?php $__currentLoopData = $itemsInCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="item-description">
                                <?php echo e($item->description); ?>

                                
                                <?php if(isset($item->notes) && strtolower(trim($item->notes)) === 'included'): ?>
                                    <span class="included-note">Included</span>
                                <?php endif; ?>
                            </td>
                            <td class="item-amount text-right">
                                <?php if(isset($item->notes) && strtolower(trim($item->notes)) === 'included'): ?>
                                    
                                <?php else: ?>
                                    $<?php echo e(number_format($item->amount, 2)); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr class="category-total-row">
                            <td class="bold text-right"><?php echo e($categoryName); ?> Total</td>
                            <td class="bold text-right">$<?php echo e(number_format($categoryTotals[$categoryName], 2)); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                
                <tr class="amount-due-footer-row">
                    <td class="bold" style="padding: 8px;">Amount Due</td>
                    <td class="bold text-right" style="padding: 8px;">$<?php echo e(number_format($statement->total_amount, 2)); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>

    
    <div class="ways-to-pay-section">
        <table class="no-border">
            <tr>
                <td style="width: 60%; vertical-align: top; padding-right: 15px;">
                    <h3 class="section-heading">Ways to Pay</h3>
                    <div class="payment-option">
                        <span class="payment-icon">💲</span> 
                        <span class="bold">Auto Pay:</span> Visit <a href="<?php echo e($companySettings['autopay_url_link'] ?? '#'); ?>" class="brand-blue-text"><?php echo e($companySettings['autopay_url_text'] ?? 'Spectrum.net/AutoPay'); ?></a>. Auto Pay is the easiest way to pay your bill on time every month.
                    </div>
                    <div class="payment-option">
                        <span class="payment-icon">📱</span>
                        <span class="bold">App:</span> Pay your bill through the My Spectrum App.
                    </div>
                    <div class="payment-option">
                        <span class="payment-icon">💻</span>
                        <span class="bold">Online:</span> Pay your bill online at <a href="<?php echo e($companySettings['online_billing_url_link'] ?? '#'); ?>" class="brand-blue-text"><?php echo e($companySettings['online_billing_url_text'] ?? 'Spectrum.net'); ?></a>.
                        Want to go paperless? Visit <a href="<?php echo e($companySettings['paperless_url_link'] ?? '#'); ?>" class="brand-blue-text"><?php echo e($companySettings['paperless_url_text'] ?? 'Spectrum.net/billing'); ?></a>.
                    </div>
                    <div class="payment-option">
                        <span class="payment-icon">📞</span>
                        <span class="bold">Phone:</span> Call the automated payment service at <a href="tel:<?php echo e($companySettings['phone_payment_number_tel'] ?? '8332676097'); ?>" class="brand-blue-text"><?php echo e($companySettings['phone_payment_number_display'] ?? '(833) 267-6097'); ?></a>.
                    </div>
                </td>
                <td style="width: 40%; vertical-align: top; background-color: #f8f9fa; padding: 12px; border-radius: 4px;">
                    <h3 class="section-heading"><span class="payment-icon">📍</span> Store</h3>
                    <p class="store-address">
                        <?php echo e($companySettings['store_address_line1'] ?? '557 N Afalaya Tr, Ste J03B'); ?><br>
                        <?php echo e($companySettings['store_address_line2'] ?? 'Orlando, FL 32828'); ?>

                    </p>
                    <p class="store-hours"><?php echo e($companySettings['store_hours_display'] ?? 'Store Hours: Mon thru Sat - 10:00am to 8:00pm; Sun - 12:00pm to 5:00pm'); ?></p>
                    <p><a href="<?php echo e($companySettings['store_locator_url_link'] ?? '#'); ?>" class="brand-blue-text">Visit <?php echo e($companySettings['store_locator_url_text'] ?? 'Spectrum.com/stores'); ?> for additional locations and hours.</a></p>
                </td>
            </tr>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\utility-site\resources\views/pdfs/partials/bill_details.blade.php ENDPATH**/ ?>