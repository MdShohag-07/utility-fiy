

<aside class="dashboard-sidebar hidden md:block">
    <nav>
        <ul>
            
            <li> <a href="<?php echo e(route('my-account.index')); ?>" class="<?php echo e(($active ?? '') === 'home' || ($active ?? '') === 'dashboard' ? 'active' : ''); ?>"> <i class="fas fa-home fa-fw sidebar-icon"></i><span class="sidebar-text">Dashboard</span></a> </li>
            <li> <a href="<?php echo e(route('my-account.billing.index')); ?>" class="<?php echo e(($active ?? '') === 'billing' ? 'active' : ''); ?>"> <i class="fas fa-file-invoice-dollar fa-fw sidebar-icon"></i><span class="sidebar-text">Billing</span></a> </li>
            <li> <a href="<?php echo e(route('my-account.services.index')); ?>" class="<?php echo e(($active ?? '') === 'services' ? 'active' : ''); ?>"> <i class="fas fa-concierge-bell fa-fw sidebar-icon"></i><span class="sidebar-text">Services</span></a> </li>
            <li> <a href="#" class="<?php echo e(($active ?? '') === 'upgrade' ? 'active' : ''); ?>"> <i class="fas fa-shopping-cart fa-fw sidebar-icon"></i><span class="sidebar-text">Upgrade</span></a> </li>
            <li> <a href="#" class="<?php echo e(($active ?? '') === 'support' ? 'active' : ''); ?>"> <i class="fas fa-headset fa-fw sidebar-icon"></i><span class="sidebar-text">Support</span></a> </li>
            <li> <a href="#" class="<?php echo e(($active ?? '') === 'more' ? 'active' : ''); ?>"> <i class="fas fa-ellipsis-h fa-fw sidebar-icon"></i><span class="sidebar-text">More</span></a> </li>

            <hr class="sidebar-divider">

            <li> <a href="#"><i class="fas fa-comments fa-fw sidebar-icon"></i><span class="sidebar-text">Chat With Us</span></a> </li>
            
            <li>
                <a href="<?php echo e(route('my-account.profile.edit')); ?>" class="<?php echo e(request()->routeIs('my-account.profile.edit') || request()->routeIs('profile.edit') ? 'active' : ''); ?>">
                    <i class="fas fa-user-cog fa-fw sidebar-icon"></i><span class="sidebar-text">Edit Profile</span>
                </a>
            </li>
            

             
             <li class="mt-auto pt-4 border-t border-gray-700">
                 <a href="#logout"
                    onclick="event.preventDefault(); if(confirm('Are you sure?')) { document.getElementById('dashboard-logout-form').submit(); }">
                     <i class="fa-solid fa-arrow-right-from-bracket fa-fw sidebar-icon"></i>
                     <span class="sidebar-text">Logout</span>
                 </a>
                 <form id="dashboard-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>
             </li>
        </ul>
    </nav>
</aside><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/partials/user_dashboard_sidebar.blade.php ENDPATH**/ ?>