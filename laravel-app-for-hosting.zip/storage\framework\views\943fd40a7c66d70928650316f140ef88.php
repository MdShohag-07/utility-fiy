


<?php $__env->startSection('title', 'Link User Accounts'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-content user-link-page px-4 py-4 md:px-6 md:py-6">

    
    <div class="dashboard-header-v3 mb-4">
        <div class="header-greeting">
            <h1 class="text-2xl md:text-3xl font-semibold text-[var(--primary-color)]">
                <i class="fas fa-link fa-fw mr-2 text-[var(--accent-color)]"></i> Link User Accounts
            </h1>
            <p class="text-gray-600 mt-1">Select two user accounts to link them for shared billing statements.</p>
        </div>
    </div>
    <hr class="mb-5">

    
    <?php echo $__env->make('partials.admin_alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="widget-card settings-form-widget shadow-lg border border-gray-100 rounded-lg overflow-hidden">
         <div class="widget-header bg-white border-b border-gray-200">
             <h3 class="text-base font-medium text-gray-700"><i class="fas fa-pencil-alt fa-fw mr-2 text-gray-400"></i> Select Users to Link</h3>
         </div>

         <form action="<?php echo e(route('admin.users.link.store')); ?>" method="POST">
             <?php echo csrf_field(); ?>

             <div class="widget-content space-y-6">

                <p class="text-sm text-gray-700">Select the two user accounts you wish to appear on the same billing statement. Note: This functionality requires further backend implementation.</p>

                
                <div class="form-group">
                    <label for="user_id_1" class="form-label">First User Account <span class="text-red-500">*</span></label>
                    <select name="user_id_1" id="user_id_1" class="form-control <?php $__errorArgs = ['user_id_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">-- Select First User --</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id_1') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?> (<?php echo e($user->username); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-message mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     <?php $__errorArgs = ['user_id_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                         <?php if($message === 'The user id 2 and user id 1 must be different.'): ?>
                            <div class="error-message mt-1">Please select two different users.</div>
                         <?php endif; ?>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="form-group">
                    <label for="user_id_2" class="form-label">Second User Account <span class="text-red-500">*</span></label>
                     <select name="user_id_2" id="user_id_2" class="form-control <?php $__errorArgs = ['user_id_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">-- Select Second User --</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id_2') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->last_name); ?>, <?php echo e($user->first_name); ?> (<?php echo e($user->username); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-message mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

             </div> 

             <div class="widget-footer bg-gray-50 p-3 border-t border-gray-200 flex justify-end">
                 <button type="submit" class="btn btn-primary">Link Selected Users</button>
             </div>
         </form> 
    </div> 


     

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
<style>
    .form-label { display: block; margin-bottom: 0.4rem; font-weight: 500; font-size: 0.9rem; color: var(--dark-color); }
    .form-control, select.form-control { width: 100%; padding: 0.6rem 0.8rem; border: 1px solid #d1d5db; border-radius: var(--border-radius, 6px); font-size: 0.95rem; transition: border-color 0.2s ease, box-shadow 0.2s ease; background-color: #f9fafb; }
    .form-control:focus, select.form-control:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 3px rgba(0, 94, 184, 0.15); background-color: #fff;}
    .form-control.input-error, select.form-control.input-error { border-color: var(--danger-color, #e74c3c); }
    .error-message { color: var(--danger-color, #e74c3c); font-size: 0.8rem; margin-top: 4px; }
    .alert { border-radius: var(--border-radius); border-width: 1px; }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dzm/public_html/spectrum.mylogin.vip/resources/views/admin/users/link.blade.php ENDPATH**/ ?>